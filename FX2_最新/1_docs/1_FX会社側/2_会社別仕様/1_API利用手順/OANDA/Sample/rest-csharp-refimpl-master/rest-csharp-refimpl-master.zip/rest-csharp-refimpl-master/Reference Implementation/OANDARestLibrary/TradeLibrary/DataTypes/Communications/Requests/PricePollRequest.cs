﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OANDARestLibrary.TradeLibrary.DataTypes.Communications.Requests
{
    public class PricePollRequest
    {
        public List<string> prices;
    }
}
