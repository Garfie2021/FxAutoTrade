﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TradeLibrary.DataModels
{
    enum EOrderType
    {
        Market,
        FillOrKill,
        ImmediateOrCancel
    }
}
